//cancel button

let checkout;
window.onload = function () {
    checkout=document.getElementById("checkout_summary");

}
