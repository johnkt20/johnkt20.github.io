
//AddTocart button
let cancelChecoutForm;
let addcart;
let checkoutButton;

window.onload = function () {
    addcart=document.getElementsByClassName("addToCart");
    cancelChecoutForm=document.getElementById("cancel_btn");
    checkoutButton=document.getElementById("checkout_btn");



    cancelChecoutForm.onclick=closeForm;
    for(const btns of addcart){
        btns.onclick=addToCart;
    }
}
function closeForm() {
    document.getElementById("myForm").style.display = "none";
}



function addToCart() {

    let productId={id:this.id};

    fetch('/addtocart.jsp', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(productId),
    })
        .then(response => response.json())
        .then(data => processData(data))
        .catch((error) => {
            console.error('Error:', error);
        });
    //e.target.reset();
    //e.preventDefault();
}

function processData(data) {
    let cartCounter= document.getElementById("cartCounter");
console.log(data);
       cartCounter.textContent=parseInt(cartCounter.textContent)+1;
    let tr = document.createElement('tr');
    let btn=document.createElement('button');
    btn.textContent="delete";
    btn.className="deletfromcart";



      let td2= document.createElement('td');
    for (let key in data) {
        let td = document.createElement('td');
        td.innerText = data[key];
       //td.appendChild(btn);
        tr.append(td);
    }
    td2.appendChild(btn);
    tr.append(td2);
    document.querySelector("#cartlist>tbody").append(tr);

}


<!-- pop up -->
let openform= document.getElementById("openfrm");
openform.onclick=openForm;

function openForm() {
    document.getElementById("myForm").style.display = "block";
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}






/// Delete Product from Cart

var deleteProductId;
var deletProduct=function deletFromCart() {
//alert("your in ajax");
    let productId={id:deleteProductId};
    console.log("product id"+ this.id);
    fetch('/deletefromcart.jsp', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(productId),
    })
        .then(response => response.json())
        .then(data => processData3(data))
        .catch((error) => {
            console.error('Error:', error);
        });
    //e.target.reset();
    //e.preventDefault();
}

function processData3(data) {

    let cartCounter= document.getElementById("cartCounter");
    cartCounter.textContent=parseInt(cartCounter.textContent)-1;

}






/// functionalliyt to handle event from table and button
let elements = document.getElementsByClassName("deletfromcart");

let myFunction = function(e) {
   // e.stopImmediatePropagation();
    let attribute = this.getAttribute("data-myattribute");
    //tst
    var kk = this.parentNode.parentNode.rowIndex;
    deleteProductId= document.getElementById("cartlist").rows[kk].cells[0].innerHTML;
    //deletefrom front
    document.getElementById("cartlist").deleteRow(kk);
    alert("Product removed from cart!!");

    //e.preventDefault();
    deletProduct();
};

for (let m = 0; m < elements.length; m++) {
    elements[m].addEventListener('click', myFunction, false);
}





