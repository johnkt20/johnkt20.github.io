window.onload = function () {
    //document.querySelector('form').addEventListener('submit', addProduct);
    let btnadd= document.getElementById("btnadd");
    let btndelet=document.getElementById("deletebtn");
    btndelet.onclick=delteProduct;
      btnadd.onclick=addProduct;
}

function addProduct(e) {
    console.log("addproduct by tek");
    let productName = document.getElementById('product_name').value;
    let productPrice = document.getElementById('product_price').value;
    let product = {name: productName, price: productPrice};
    fetch('product', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(product),
    })
        .then(response => response.json())
        .then(data => processData(data))
        .catch((error) => {
            console.error('Error:', error);
        });
    console.log("addproduct");
    //e.target.reset();
    e.preventDefault();
}

function processData(data) {
    alert("process Data");
    let tr = document.createElement('tr');
    for (let key in data) {
        let td = document.createElement('td');
        td.innerText = data[key];
        tr.append(td);
    }
    document.querySelector("#tableProducts").append(tr);


}





/// Delete product

function delteProduct(e){
    console.log("deletebuttonclicked");
    let productId=document.getElementById("productId").value;
    let product = {id: productId};
    fetch('/deleteproduct.jsp', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(product),
    })
        .then(response => response.json())
        .then(data => processData2(data))
        .catch((error) => {
            console.error('Error:', error);
        });
    e.target.reset();
   // e.preventDefault();
}

function processData2(data) {

    let prodctId=data.id;
    let table = document.getElementById("tableProducts");
   console.log("cell value"+table.rows[1].cells[0].innerHTML);
    for (let i in table.rows) {
        let row = table.rows[i]
        //iterate through rows
        //rows would be accessed using the "row" variable assigned in the for loop
        for (let j in row.cells) {
            let col = row.cells[j]
            if(col.innerHTML===prodctId){
               table.deleteRow(i);
            }
            //iterate through columns
            //columns would be accessed using the "col" variable assigned in the for loop
        }
    }



}
