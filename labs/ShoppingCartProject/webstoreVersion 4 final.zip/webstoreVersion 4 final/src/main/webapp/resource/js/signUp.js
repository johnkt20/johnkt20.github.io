window.onload = function () {
    document.querySelector('form').addEventListener('submit', addUser);
}

function addUser(e) {
    let fName = document.getElementById('fName').value;
    let lName = document.getElementById('lName').value;
    let userName = document.getElementById('user_name').value;
    let password = document.getElementById('password').value;
    localStorage.setItem("userName",userName);
    localStorage.setItem("password",password);

    let signup = {firstName:fName, lastName:lName, userName: userName, password: password};
    fetch('signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(signup),
    })
        .then(response => response.json())
        //.then(data => processData(data))
        //.catch((error) => {
          //  console.error('Error:', error);
   // });

    e.target.reset();
    e.preventDefault();
}
/*
function processData(data) {
    let tr = document.createElement('p');
    for (let key in data) {
        let td = document.createElement('div');
        td.innerText = data[key];
        tr.append(td);
    }
    document.querySelector("#tbl_users>tbody").append(tr);*/



