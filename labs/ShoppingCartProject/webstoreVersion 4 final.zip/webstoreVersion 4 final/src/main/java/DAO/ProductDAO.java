package DAO;

import model.Customer;
import model.Product;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductDAO {

   private static ProductDAO dao;
    Map<String, Product> productsDb = new HashMap<>();
    Map<String, Customer> customerDb= new HashMap<>();

    private ProductDAO() {
        // Products
        productsDb.put("P323", new Product("P323", "hp250", "549"));
        productsDb.put("P234", new Product("P234", "DELL", "650"));
        productsDb.put("P364", new Product("P364", "MAC", "750"));

        //Customers
        customerDb.put("1234", new Customer("yohannes","1234","1234"));
        customerDb.put("456",new Customer("aziza","456","456"));
        customerDb.put("789", new Customer("freiw","789","789"));

        //
    }
    public static ProductDAO getDAO(){

     if(null==dao){
         dao= new ProductDAO();
         return dao;
     }
     else{
         return dao;
     }


    }

    public void addProduct(Product product){
        productsDb.put(product.getId(), product);
    }

    public void deleteProduct(String productId){
        productsDb.remove(productId);
    }

    public void updateProduct(Product product){
        productsDb.put(product.getId(), product);
    }

    public List<Product> getAllProducts(){
        return new ArrayList<>(productsDb.values());
    }

    public Product getProductById(String productId){
        return productsDb.get(productId);
    }

    public String genId() {
        return "P"+(int)Math.floor(Math.random()*1000);
    }


//cusomermethods
public void addCustomer(Customer customer){
   customerDb.put(customer.getPassword(),customer);
}

public void deleteProduct(int customerId){
        customerDb.remove(customerId);
}


public List<Customer> getAllCustomers(){
        return new ArrayList<>(customerDb.values());
}
}
