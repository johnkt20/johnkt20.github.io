package Controller;

import DAO.ProductDAO;
import com.google.gson.Gson;
import model.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/addtocart.jsp")
public class AddToCart extends HttpServlet {

    private ProductDAO dao;
    Gson mapper = new Gson();
    List<Product> products;

    @Override
    public void init() throws ServletException {
        dao = ProductDAO.getDAO();
        products= new ArrayList<Product>();
    }


    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        HttpSession session=request.getSession();
        ///

        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } finally {
            reader.close();
        }

        String json = sb.toString();
        Product product = mapper.fromJson(json, Product.class);
        Product buyProduct=dao.getProductById(product.getId());

        products.add(buyProduct);

        session.setAttribute("AddToCart",products);
        session.setAttribute("AddToCartSize",products.size());
        System.out.println("Sesssion updated");
        System.out.println("size of cart is " + products.size());
        PrintWriter out = response.getWriter();
        out.print(mapper.toJson(buyProduct));
    }
}