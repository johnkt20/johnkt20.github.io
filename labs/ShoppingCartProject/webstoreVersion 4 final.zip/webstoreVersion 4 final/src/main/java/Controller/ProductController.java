package Controller;

import DAO.ProductDAO;
import model.Product;
import com.google.gson.Gson;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class ProductController
 */


@WebServlet({"/product", ""})
public class ProductController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private ProductDAO dao;
    Gson mapper = new Gson();

    @Override
    public void init() throws ServletException {
        dao = ProductDAO.getDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //main product page loading
        HttpSession session = request.getSession();
        session.setAttribute("products", dao.getAllProducts());
        // request.setAttribute("products", dao.getAllProducts());
        RequestDispatcher view = request.getRequestDispatcher("product.jsp");
        view.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

            //AddProduct from admin panel

            List<Product> updatedProductList = new ArrayList<>();
            updatedProductList = dao.getAllProducts();
            StringBuilder sb = new StringBuilder();
            BufferedReader reader = request.getReader();
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
            } finally {
                reader.close();
            }

            String json = sb.toString();
            Product product = mapper.fromJson(json, Product.class);
            product.setId(dao.genId());
            System.out.println("addProduct" + product);
            dao.addProduct(product);
            HttpSession session = request.getSession();
            session.setAttribute("products", dao.getAllProducts());

            System.out.println("all" + dao.getAllProducts());
            PrintWriter out = response.getWriter();
            System.out.println("productController"+product);
            out.print(mapper.toJson(product));
        }



    }

