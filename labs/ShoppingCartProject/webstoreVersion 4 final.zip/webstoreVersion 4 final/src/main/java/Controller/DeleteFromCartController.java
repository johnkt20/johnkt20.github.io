package Controller;

import DAO.ProductDAO;
import com.google.gson.Gson;
import model.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet("/deletefromcart.jsp")
public class DeleteFromCartController extends HttpServlet {

    private ProductDAO dao;
    Gson mapper = new Gson();

    @Override
    public void init() throws ServletException {
        dao = ProductDAO.getDAO();
    }
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response){


    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Product> productsAfterDelete = new ArrayList<>();

        //DeleteFromCart
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } finally {
            reader.close();
        }

        String json = sb.toString();
        Product product = mapper.fromJson(json, Product.class);
        System.out.print("product"+product);
        System.out.print("productId"+product.getId());

        String productId=product.getId();
        HttpSession session = request.getSession();

        productsAfterDelete=(List<Product>)session.getAttribute("AddToCart");
        System.out.println("productBeforeDelete1"+productsAfterDelete.size());
       //List<Product> updatedProduct= productsAfterDelete.stream().filter(n->!(n.getId().equalsIgnoreCase(productId))).collect(Collectors.toList());
      for(Product pro:productsAfterDelete){
          if(pro.getId().equalsIgnoreCase(productId)){
              productsAfterDelete.remove(pro);
          }
      }

       System.out.println("productBeforeDelete2"+productsAfterDelete.size());
       session.setAttribute("AddToCart",productsAfterDelete);
        session.setAttribute("AddToCartSize", productsAfterDelete.size());

        System.out.println("AfterDelere"+dao.getAllProducts());
        PrintWriter out = response.getWriter();
        out.print(mapper.toJson(product));
    }

}


