package Controller;

import DAO.ProductDAO;
import DAO.UserDAO;
import model.User;
import model.UserInfo;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/customerlogin.jsp")
public class LoginServlet extends HttpServlet {
    private UserDAO dao;
    @Override
    public void init() throws ServletException {
        dao = new UserDAO();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       // HttpSession session = req.getSession(true);
        /*
        if(session != null){
            req.setAttribute("err_msg", session.getAttribute("err_msg"));
            session.invalidate();//server cant identify the client which has visited in
            // previous.So now it creates a new session id for that client.
            System.out.print("do get in serlet inside");
        }
        */

        RequestDispatcher view= req.getRequestDispatcher("/WEB-INF/customerlogin.jsp");
        view.forward(req,resp);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("do post");
        String userName = req.getParameter("user_name");
        String remember = req.getParameter("remember");
        UserInfo user = UserDAO.userDb.get(userName);
        HttpSession session = req.getSession();

        // UserInfo pass = UserDAO.userDb.get(password);
        if (user!=null && user.getPassword().equals(req.getParameter("pass")) ) {

            session.setAttribute("user", user);
            //session.setAttribute("user", new User(userName, password));
            if ("yes".equals(remember)) {
                Cookie c = new Cookie("user", userName);
                c.setMaxAge(30 * 24 * 60 * 60);
                resp.addCookie(c);
            } else {
                Cookie c = new Cookie("user", null);
                c.setMaxAge(0);
                resp.addCookie(c);

            }
            resp.sendRedirect("welcome.jsp");
        } else {
            session.setAttribute("err_msg", "Username and/or password invalid.");
            resp.sendRedirect("/customerlogin.jsp");
        }
    }

}


