package Controller;

import DAO.ProductDAO;
import com.google.gson.Gson;
import model.Product;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/login")
public class LoginController extends HttpServlet{

    private ProductDAO dao=ProductDAO.getDAO();
    Gson mapper = new Gson();

        @Override
        public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                 //
            HttpSession session= request.getSession();
            if(session.getAttribute("admin")!=null){
                RequestDispatcher req = request.getRequestDispatcher("WEB-INF/AdminPanel.jsp");
                req.forward(request, response);
            }
            else{
                response.sendRedirect("/");
            }


            }

            @Override
            public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

                HttpSession session= request.getSession();
                System.out.println("requestUrlIs" + request.getRequestURI());
                System.out.println("doget in login");
                String userr = request.getParameter("user");
                String pass = request.getParameter("password");
                System.out.println(userr + "" + pass);
                if (userr.equals("admin") && pass.equals("1234")) {
                    session.setAttribute("admin","admin");
                    request.setAttribute("products", dao.getAllProducts());
                    //RequestDispatcher req = request.getRequestDispatcher("WEB-INF/AdminPanel.jsp");
                   // req.forward(request, response);
                    response.sendRedirect("login");
                } else {
                    response.sendRedirect("/");
                }
            }
        }

