package Controller;

import DAO.ProductDAO;
import com.google.gson.Gson;
import model.Product;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/deleteproduct.jsp")
public class DeleteController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private ProductDAO dao;
    Gson mapper = new Gson();

    @Override
    public void init() throws ServletException {
        dao = ProductDAO.getDAO();
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        /*
        //main product page loading
        HttpSession session = request.getSession();
        session.setAttribute("products", dao.getAllProducts());
        // request.setAttribute("products", dao.getAllProducts());
        RequestDispatcher view = request.getRequestDispatcher("product.jsp");
        view.forward(request, response);
    }
*/
    }
@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    List<Product> productsAfterDelete = new ArrayList<>();

System.out.println("dopost in delete");
        //DeleteProduct
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } finally {
            reader.close();
        }

        String json = sb.toString();
        Product product = mapper.fromJson(json, Product.class);
        System.out.print("product"+product);
        System.out.print("productId"+product.getId());

        String productId=product.getId();
        dao.deleteProduct(productId);

        HttpSession session = request.getSession();
        session.setAttribute("products", dao.getAllProducts());


        System.out.println("AfterDelere"+dao.getAllProducts());
        PrintWriter out = response.getWriter();
        out.print(mapper.toJson(product));
    }

}

