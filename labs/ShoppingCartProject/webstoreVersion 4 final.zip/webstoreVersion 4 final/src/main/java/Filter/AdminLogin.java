package Filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;


public class AdminLogin implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req= (HttpServletRequest)request;
        HttpSession session= req.getSession();
        if(session.getAttribute("admin")!=null){
            RequestDispatcher disp= req.getRequestDispatcher("AdminPanel");
        }

    }

    @Override
    public void destroy() {

    }
}
