package cstechsupport;

import javax.servlet.ServletContext;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.util.Random;


public class TechSupport extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        PrintWriter out= resp.getWriter();
        out.print("<html>");
        out.print("<body>");
        out.print("<h2> cstech support</h2>");
        out.print("<form action='techsupport' method='post'>");
        out.print("<div>");
        out.print(" Name:"+" "+"<input  name='username' type='text' required>");
        out.print("</div>");
        out.print("<div>");
        out.print("Email-Adress:"+" "+"<input name='username' type='text'  required>");
        out.print("</div>");
        out.print("<div>");
        out.print("Problem:"+" "+"<input name='username' type='text' required>");
        out.print("</div>");
        out.print("<div>");
        out.print("ProblemDescrprtion: "+" "+"<textarea name='username' padding-bottom='200px' padding-right='500px'>"+"</textarea>");
        out.print("<div>");
        out.print("<input type='submit' value='help'>");
        out.print("</form");
        out.print("</body>");
        out.print("</html>");
    }
    @Override
    public void doPost (HttpServletRequest req, HttpServletResponse resp) throws IOException {
        //String str=req.getParameter("username");
       String [] arr= req.getParameterValues("username");
        ServletContext sc = this.getServletContext();
        String email= sc.getInitParameter("email");
        Random rand= new Random();
        String ticketNumber= "TN" +rand.nextInt(100);

        PrintWriter postback= resp.getWriter();

        postback.print("Thank you!!"+" "+ arr[0]+"for contacting us"+"\n");
        postback.print("We should receive reply from us with in 24 hrs in\n" +
                "your email address::-"+arr[1]+"\n");
        postback.print("Let us know in our support email::-"+" "+email+ " ");
        postback.print("if\n" +
                "you don’t receive reply within 24 hrs. Please be sure to attach your reference\n" +"TicketNumber::-"+" "+ticketNumber+
                 "in your email");
        postback.print("Thank you for contacting us!!");
        System.out.print("post mehtod called");

    }

}
