package product;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/product.jsp")
public class ViewProduct extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp){

System.out.println("checki do get"+ req.getParameter("jeans"));
    }


}
